# EndProject_Hajduk
Ending Project for Computer Sience 2018

TODO as of 2018-06-10::	
)Finish tables in sql and add 1 dataset to each  
)Set up data for using in WPF
)Raw Design WPF
)Connect WPF to Logic
)Add saving and Loading
)Save Possibility
)Fine Design WPF
)Check for Errors
)Make installer

Optional:
  -Make Unitest
  -Look for things you missed (u sureley did :])
  
 last hours before submission check for additional features
 Compile, make installer send to frend to test.
